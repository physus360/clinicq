with open('src/StaffApp.jsx', 'r', encoding='utf-8') as f:
    content = f.read()

changes = 0

# Account codes and which ones get police service number and rank
ACCOUNT_CODES = ["PACT", "FACT", "BACT", "EACT", "CACT", "WACT", "RACT", "WPACT", "TACT"]
POLICE_SVC_CATEGORIES = ["PACT", "FACT", "BACT", "EACT", "WACT", "RACT", "WPACT"]
RANK_CATEGORIES = ["PACT"]

MPS_RANKS = [
    "Commissioner of Police",
    "Deputy Commissioner of Police",
    "Assistant Commissioner of Police",
    "Chief Superintendent of Police",
    "Superintendent of Police",
    "Chief Inspector of Police",
    "Inspector of Police",
    "Sub Inspector of Police",
    "Police Senior Sergeant",
    "Police Sergeant",
    "Police Constable",
    "Police Recruit",
]

# 1. Replace PatientFormFields category dropdown
old_category = '''      <div className="field-group">
        <label className="field-label">Patient Category</label>
        <select className="field-input" value={form.category || "General"} onChange={(e) => setForm({ ...form, category: e.target.value })}>
          <option value="General">General</option>
          <option value="Police">Police</option>
          <option value="Police EXO">Police EXO</option>
          <option value="Police Family">Police Family</option>
          <option value="Emergency">Emergency</option>
          <option value="Police Custody">Police Custody</option>
        </select>
      </div>
      {["Police", "Police EXO", "Police Family", "Police Custody", "Emergency"].includes(form.category) && (
        <div className="field-group">
          <label className="field-label">Police Service No <span className="dim" style={{ fontWeight: 400 }}>(4-digit)</span></label>
          <input
            className="field-input"
            style={{ maxWidth: "140px" }}
            maxLength={4}
            placeholder="e.g. 1234"
            value={form.policeServiceNo || ""}
            onChange={(e) => setForm({ ...form, policeServiceNo: e.target.value.replace(/\\D/g, "").slice(0, 4) })}
          />
        </div>
      )}'''

new_category = '''      <div className="field-group">
        <label className="field-label">Patient Account <span style={{ color: "var(--red)" }}>*</span></label>
        <select className="field-input" value={form.category || ""} onChange={(e) => setForm({ ...form, category: e.target.value, rank: "" })}>
          <option value="" disabled>— Select account —</option>
          <option value="PACT">PACT — Police Account</option>
          <option value="FACT">FACT — Police Family Account</option>
          <option value="BACT">BACT — Arrest Account</option>
          <option value="EACT">EACT — Emergency Account</option>
          <option value="CACT">CACT — Citizen Account</option>
          <option value="WACT">WACT — Polwec Account</option>
          <option value="RACT">RACT — Retired Police Account</option>
          <option value="WPACT">WPACT — WP Holder Account</option>
          <option value="TACT">TACT — Tourist Account</option>
        </select>
      </div>
      {["PACT","FACT","BACT","EACT","WACT","RACT","WPACT"].includes(form.category) && (
        <div className="field-group">
          <label className="field-label">Police Service No <span className="dim" style={{ fontWeight: 400 }}>(4-digit)</span></label>
          <input
            className="field-input"
            style={{ maxWidth: "140px" }}
            maxLength={4}
            placeholder="e.g. 1234"
            value={form.policeServiceNo || ""}
            onChange={(e) => setForm({ ...form, policeServiceNo: e.target.value.replace(/[^0-9]/g, "").slice(0, 4) })}
          />
        </div>
      )}
      {form.category === "PACT" && (
        <div className="field-group">
          <label className="field-label">Rank</label>
          <select className="field-input" value={form.rank || ""} onChange={(e) => setForm({ ...form, rank: e.target.value })}>
            <option value="">— Select rank —</option>
            <option>Commissioner of Police</option>
            <option>Deputy Commissioner of Police</option>
            <option>Assistant Commissioner of Police</option>
            <option>Chief Superintendent of Police</option>
            <option>Superintendent of Police</option>
            <option>Chief Inspector of Police</option>
            <option>Inspector of Police</option>
            <option>Sub Inspector of Police</option>
            <option>Police Senior Sergeant</option>
            <option>Police Sergeant</option>
            <option>Police Constable</option>
            <option>Police Recruit</option>
          </select>
        </div>
      )}'''

if old_category in content:
    content = content.replace(old_category, new_category)
    print("OK 1: PatientFormFields category updated")
    changes += 1
else:
    old2 = old_category.replace('\n', '\r\n')
    if old2 in content:
        content = content.replace(old2, new_category)
        print("OK 1: PatientFormFields category updated (CRLF)")
        changes += 1
    else:
        print("!! 1: PatientFormFields category not found")

# 2. Update blank form objects - remove "General" default, add rank field
old_blank1 = '{ idNumber: "", name: "", mobile: "", dob: "", sex: "", category: "General", policeServiceNo: "", address: "", notes: "" }'
new_blank1 = '{ idNumber: "", name: "", mobile: "", dob: "", sex: "", category: "", rank: "", policeServiceNo: "", address: "", notes: "" }'
count1 = content.count(old_blank1)
content = content.replace(old_blank1, new_blank1)
print(f"OK 2: Updated {count1} blank form objects")
changes += 1

# 3. Update patient load expressions - add rank field
old_load = 'sex: p.sex || "", category: p.category || "General", policeServiceNo: p.policeServiceNo || "", address: p.address || "", notes: p.notes || ""'
new_load = 'sex: p.sex || "", category: p.category || "", rank: p.rank || "", policeServiceNo: p.policeServiceNo || "", address: p.address || "", notes: p.notes || ""'
count2 = content.count(old_load)
content = content.replace(old_load, new_load)
print(f"OK 3: Updated {count2} patient load expressions")
changes += 1

# 4. Update doctor portal badge - show account code directly
old_badge1 = '{current.patientCategory && current.patientCategory !== "General" && ('
new_badge1 = '{current.patientCategory && ('
if old_badge1 in content:
    content = content.replace(old_badge1, new_badge1)
    print("OK 4: Doctor portal Now Serving badge updated")
    changes += 1

old_badge2 = '{p.patientCategory && p.patientCategory !== "General" && ('
new_badge2 = '{p.patientCategory && ('
if old_badge2 in content:
    content = content.replace(old_badge2, new_badge2)
    print("OK 5: Doctor portal patient list badge updated")
    changes += 1

# 5. Update booking patientCategory field
old_booking = 'patientCategory: patientForm.category || "General",'
new_booking = 'patientCategory: patientForm.category || "",'
if old_booking in content:
    content = content.replace(old_booking, new_booking)
    print("OK 6: Booking patientCategory default removed")
    changes += 1

# 6. Update display in active appointments - show account code
old_display = '`${patientForm.category && patientForm.category !== "General" && ` · ${patientForm.category}`}`'
# Just update the category display reference
old_disp2 = '{patientForm.category && patientForm.category !== "General" && ` · ${patientForm.category}`}'
new_disp2 = '{patientForm.category && ` · ${patientForm.category}`}'
if old_disp2 in content:
    content = content.replace(old_disp2, new_disp2)
    print("OK 7: Booking form category display updated")
    changes += 1

with open('src/StaffApp.jsx', 'w', encoding='utf-8') as f:
    f.write(content)

print(f"\nDone - {changes} changes applied. Run: npm run dev")
