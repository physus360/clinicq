-- Add rank column to patients table
ALTER TABLE patients ADD COLUMN IF NOT EXISTS rank TEXT;
